import { View, Text } from "react-native-web";
import Detalhes from "./sources/telas/Carrinho/Detalhes";
import Topo from "./sources/telas/Carrinho/Topo";
import Mocks from "./sources/mocks/carrinho";
import { FlatList } from "react-native";
import Item from "./sources/telas/Carrinho/Item";

export default function App(){
  return(
    <View>
      <Text>Principal</Text>
      <Topo {...Mocks.topo}/>
      <Detalhes {...Mocks.detalhes} />

      <FlatList 
      data={Mocks.itens.lista}
      renderItem={Item}
      keyExtractor={({nome})=>nome}
      />
    </View>
  )
}